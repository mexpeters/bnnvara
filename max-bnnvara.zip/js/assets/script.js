(function ($) {

    'use strict';

    var storyTrigger = '.trigger-story',
        tipsTrigger = '.trigger-tips',
        storyPopup = '.popup-box.state-story',
        tipsPopup = '.popup-box.state-tips',
        stateOpen = 'state-open',
        triggerClose = '.trigger-close';

        $(storyTrigger).on('click', function() {
            $(storyPopup).addClass(stateOpen);
        });

        $(tipsTrigger).on('click', function() {
            $(tipsPopup).addClass(stateOpen);
        });

        $(triggerClose).on('click', function() {
            $(storyPopup).removeClass(stateOpen);
            $(tipsPopup).removeClass(stateOpen);
        });

})(window.jQuery);